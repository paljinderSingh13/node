angular.module('chat', ['btford.socket-io','ngDialog','ngFileUpload','ngSanitize','angular-nicescroll']);
