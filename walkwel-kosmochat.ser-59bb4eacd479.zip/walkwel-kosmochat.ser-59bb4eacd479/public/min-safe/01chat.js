angular.module('chatModule',['ui.router',
	'app.chat.controllers',
	'app.chat.directives']);