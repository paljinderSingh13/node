angular.module('app.chat.directives',[]);
