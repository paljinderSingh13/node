angular.module('kosmochat',['ui.router',
	'ngCookies',
	
	'ngDialog',
	'btford.socket-io',
	'ui.select',
	'ui.slimscroll','chatModule']);

