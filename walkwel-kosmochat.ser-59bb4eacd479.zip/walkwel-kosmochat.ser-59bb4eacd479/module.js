'use strict';

var makeDir = {
	get : function(){
		name:'kosmochat'}
	};

module.exports = makeDir;