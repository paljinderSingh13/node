
<h2>MEAN Stack RESTful API - Education App</h2>



This repo contains the code for a RESTful API Education  App that was built using the MEAN stack:

<ul>
<li>MongoDB</li>
<li>Express</li>
<li>AngularJS</li>
<li>NodeJS</li>
</ul>



<h3>Maintain Relation between Subject , Lesson , Question and Crud </h3>







